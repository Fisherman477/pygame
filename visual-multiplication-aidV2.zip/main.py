import turtle

#-----sets turtle speed, gains user input, and sets the starting point
turtle.speed(0)
turtle.setup(800,400,0,0)
numa = turtle.textinput("number 1?", "enter the first number...")
numb = turtle.textinput("number 2?", "enter the second number...")
startX = -375
startY = 175


#-----creates one dot at any given point on our grid
def one_dot(x,y):
  turtle.penup()
  turtle.goto(startX+(20*x),startY-(20*y))
  turtle.pendown()
  turtle.dot(8)
  turtle.penup()

#-----creates one row of dots with the amount of dots being user input "number 1?"
def one_row(y):
  i = 0
  one_dot(0,0)
  while i < int(numa):
    one_dot(i,y)
    i += 1


#-----creates (x) rows of dots with x being user input "number 2?" 
def all_rows():
  k = 0
  while k < int(numb):
    one_row(k)
    k += 1


all_rows()