import random
import time

choices = ["rock","paper", "scissors"]
win = 0
lose = 0

#-----definitions
#these check for the winning player and print it
#they print the inputs so these canbe versitially used in future functions when I might want to say something different that the first function
def tie(ti, c, p):
  if c == p:
    print(ti)
def player_rock(w, l, c, p):
  global win
  global lose
  if p == "rock":
    if c == "paper":
      print(l)
      lose += 1
    if c == "scissors":
      print(w)
      win += 1
def player_paper(w, l, c, p):
  global win
  global lose
  if p == "paper":
    if c == "rock":
      print(w)
      win += 1
    if c == "scissors":
      print(l)
      lose += 1
def player_scissors(w, l, c, p):
  global win
  global lose
  if p == "scissors":
    if c == "rock":
      print(l)
      lose += 1
    if c == "paper":
      print(w)
      win += 1
#this is the basis of other modes later on
def one_round(ti, w, l):
  #define player and the computer as locals
  computer = random.choice(choices)
  player = input("rock, paper, or scissors?  ")
  #use the locals a input for our checking functions
  print("Computer picked: " + computer)
  print("You picked: " + player)
  tie(ti, computer, player)
  player_rock(w, l, computer, player)
  player_paper(w, l, computer, player)
  player_scissors(w, l, computer, player)
def three_rounds():
  global win
  global lose
  i = 0
  while i < 3:
    one_round("Tie!", "Your point!", "Computer's point!")
    i += 1
  if win > lose:
    print("You won! " + str(win) + ":" + str(lose))
  elif lose > win:
    print("You lost " + str(lose) + ":" + str(win))

def five_rounds():
  global win
  global lose
  i = 0
  while i < 5:
    one_round("Tie!", "Your point!", "Computer's point!")
    i += 1
  if win > lose: 
    print("You won! " + str(win) + ":" + str(lose))
  elif lose > win:
    print("You lost " + str(lose) + ":" + str(win))
def cont_play():
  global win
  global lose
  while True:
    one_round("Tie!", "Your point!", "Computer's point!")
    print("points (you:computer):  " + str(win) + ":" + str(lose))

while True:
  MODE = input('''
----------------------------------------------
| pick a game mode by typing one of the      |
|   number options below:                    |
|                                            |
| 1  one round                               |
| 2  three rounds                            |
| 3  five rounds                             |
| 4  continuous play                         |
|                                            |
| all options but 4 (continuous play), will  |
|  direct you back to this screen after the  |
|    game is one or lost.                    |
----------------------------------------------
      ''')
  if MODE == "1": one_round("Tie!", "You win!", "Computer wins!")
  elif MODE == "2": three_rounds()
  elif MODE == "3": five_rounds()
  elif MODE == "4": cont_play()
  time.sleep(1)